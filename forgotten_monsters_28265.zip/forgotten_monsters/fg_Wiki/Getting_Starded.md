### Getting Starded
---
---
- 1 - Basically all you have to do is become strong and avoid facing very strong monsters at the beginning of the game.

- 2 - The bosses will not spawn in the world naturally, you will need to create the summoning blocks and click on them, so that the bosses can appear.

- 3 - The first bosses will drop items that can be used in summoning blocks for the following bosses, stay tuned!

- 4 - The main thing, have fun!!
