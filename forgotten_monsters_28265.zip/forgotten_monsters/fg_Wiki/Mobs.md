## Mobs
---
---

###- Skull Normal

 HP : 15
  
 Damge : 3


###- Skull Archers

 HP : 15
  
 Damge : 3


###- Skull Sword

 HP : 15
  
 Damge : 4



 ###- Skull Berserker

 HP : 15
  
 Damge : 4


---
###- Humgry

 HP : 120
  
 Damge : 8

---
###- Spectrum

 HP : 120
  
 Damge : 8

---
###- Growler ( Texture by : j0j0n4th4n )

 HP : 15
  
 Damge : 3


---
###- Mese Lord ( Boss )

 HP : 300
  
 Damge : 7


###- Golem ( Boss )

 HP : 500
  
 Damge : 12


###- Skull King ( Boss )

 HP : 700
  
 Damge : 15

 ---


