## Recipes

---

---

#### Pick Bones

    [ Buried Bone ] [ Buried Bone ] [ Buried Bone ]
    [             ] [ Buried Bone ] [             ]
    [             ] [ Buried Bone ] [             ]

-

#### Shovel Bones

    [ Buried Bone ] [ Buried Bone ] [ ]
    [             ] [ Buried Bone ] [ ]
    [             ] [ Buried Bone ] [ ]

-

#### Axe Bones

    [ Buried Bone ] [ Buried Bone ] [ ]
    [ Buried Bone ] [ Buried Bone ] [ ]
    [             ] [ Buried Bone ] [ ]

-

#### Sword Bones

    [ ] [ Buried Bone ] [ ]
    [ ] [ Buried Bone ] [ ]
    [ ] [ Buried Bone ] [ ]

-

---

#### Old Bottle

    [             ] [ Group Glass ] [             ]
    [ Group Glass ] [ Group Glass ] [ Group Glass ]
    [ Group Glass ] [ Group Glass ] [ Group Glass ]

-

#### Healing

    [ ] [              ] [ ]
    [ ] [ Hungry Sheet ] [ ]
    [ ] [ Old Bottle ]   [ ]

-

---

#### Buried Bone Block

    [ Buried Bone ] [ Buried Bone ] [ Buried Bone ]
    [ Buried Bone ] [ Buried Bone ] [ Buried Bone ]
    [ Buried Bone ] [ Buried Bone ] [ Buried Bone ]

-

---

#### Translocation Rod

    [ ] [ Spectrum Orb ] [ ]
    [ ] [ Spectrum Orb ] [ ]
    [ ] [ Spectrum Orb ] [ ]

-

---

#### Crumpled Paper

    [ ] [ Group Leaves ] [ ]
    [ ] [ Group Leaves ] [ ]
    [ ] [ Group Leaves ] [ ]

-

#### Forgotten Book

    [ Crumpled Paper ] [ Crumpled Paper ] [ Crumpled Paper ]
    [ Crumpled Paper ] [ Crumpled Paper ] [ Crumpled Paper ]
    [ Crumpled Paper ] [ Crumpled Paper ] [ Crumpled Paper ]

-

---

#### Spectrum Orb Block

        [ Spectrum Orb ] [ Spectrum Orb ] [ Spectrum Orb ]
    
        [ Spectrum Orb ] [ Spectrum Orb ] [ Spectrum Orb ]
    
        [ Spectrum Orb ] [ Spectrum Orb ] [ Spectrum Orb ]

-

---

#### Summon Mese Lord

        [ Forgotten Book ] [ Forgotten Book ] [ Forgotten Book ]
    
        [ Spectrum Orb Block ] [ Spectrum Orb Block ] [ Forgotten Book ]
    
        [ Forgotten Book ] [ Forgotten Book ] [ Forgotten Book ]

-

#### Summon Golem

        [ Forgotten Book ] [ Spectrum Orb Block ] [ Forgotten Book ]
    
        [ Forgotten Book ] [ Heart of Mese ] [ Forgotten Book ]
    
        [ Forgotten Book ] [ Spectrum Orb Block ] [ Forgotten Book ]

-

#### Summon Skull King

        [ Forgotten Book ] [ Buried Bone Block ] [ Forgotten Book]
    
        [ Buried Bone Block ] [ Eye of the Lord ] [ Buried Bone Block ]
    
        [ Forgotten Book] [ Buried Bone Block ] [ Forgotten Book ]

---

---

---
